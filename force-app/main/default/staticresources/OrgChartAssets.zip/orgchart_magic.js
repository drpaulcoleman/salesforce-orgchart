function invokeOrgChartRemote(actionKey, args) {
    return new Promise(function (resolve, reject) {
        if (!window.Visualforce || !Visualforce.remoting || !Visualforce.remoting.Manager) {
            reject('Visualforce remoting is not loaded');
            return;
        }
        var actions = window.ORGCHART_REMOTE_ACTIONS;
        if (!actions || !actions[actionKey]) {
            reject('ORGCHART_REMOTE_ACTIONS.' + actionKey + ' is not set');
            return;
        }
        var actionName = actions[actionKey];
        var callback = function (result, event) {
            if (event.status) {
                resolve(result);
            } else if (event.type === 'exception') {
                reject(event.message || 'Apex exception');
            } else {
                reject(event.message || 'Remote action failed');
            }
        };
        var opts = { escape: true, buffer: false };
        var invokeArgs = [actionName].concat(args || []).concat([callback, opts]);
        Visualforce.remoting.Manager.invokeAction.apply(Visualforce.remoting.Manager, invokeArgs);
    });
}

/**
 * Same-origin Apex REST (OrgChartRest). Preferred on Visualforce — avoids VFRemote / InternalDialogs issues on headerless pages.
 */
function callEmployeeEndpointViaRest(url) {
    return new Promise(function (resolve, reject) {
        var base = window.ORGCHART_REST_BASE || '';
        if (!base) {
            reject('ORGCHART_REST_BASE is not set');
            return;
        }
        var u = url;
        if (url.indexOf('/hierarchy') >= 0) {
            var fteOnly = url.indexOf('employee_type=FTE') >= 0;
            u = base + '?action=hierarchy&fteOnly=' + (fteOnly ? 'true' : 'false');
        } else if (url.indexOf('/api/employees/me') >= 0) {
            u = base + '?action=me';
        } else if (url.indexOf('/api/employees?') >= 0) {
            var qs = url.split('?')[1] || '';
            var params = new URLSearchParams(qs);
            var q = params.get('search') || '';
            var lim = parseInt(params.get('limit') || '25', 10);
            if (isNaN(lim)) {
                lim = 25;
            }
            var et = params.get('employee_type') || '';
            var fteOnlySearch = et === 'FTE';
            u =
                base +
                '?action=search&q=' +
                encodeURIComponent(q) +
                '&limit=' +
                encodeURIComponent(lim) +
                '&fteOnly=' +
                (fteOnlySearch ? 'true' : 'false');
        } else {
            var m = url.match(/\/api\/employees\/(.+)/);
            if (m) {
                var idPart = decodeURIComponent(m[1]);
                u = base + '?action=detail&federationId=' + encodeURIComponent(idPart);
            }
        }
        var headers = { Accept: 'application/json' };
        // VF on vf.force.com: cookies often do not authorize /services/apexrest; page sets ORGCHART_SESSION_ID from $Api.Session_ID (API-capable).
        if (window.ORGCHART_SESSION_ID) {
            headers['Authorization'] = 'Bearer ' + window.ORGCHART_SESSION_ID;
        }
        fetch(u, { credentials: 'include', method: 'GET', headers: headers })
            .then(function (response) {
                if (response.status === 200) {
                    return response.json();
                }
                reject('Unable to fetch data. Status code: ' + response.status);
            })
            .then(resolve)
            .catch(function (err) {
                reject(err);
            });
    });
}

/**
 * If ORGCHART_REST_BASE is set (Visualforce page), use Apex REST; else JavaScript remoting + ORGCHART_REMOTE_ACTIONS.
 */
function callEmployeeEndpoint(url) {
    if (window.ORGCHART_REST_BASE) {
        return callEmployeeEndpointViaRest(url);
    }
    if (url.indexOf('/hierarchy') >= 0) {
        var fteOnly = url.indexOf('employee_type=FTE') >= 0;
        return invokeOrgChartRemote('hierarchy', [fteOnly]);
    }
    if (url.indexOf('/api/employees/me') >= 0) {
        return invokeOrgChartRemote('me', []);
    }
    if (url.indexOf('/api/employees?') >= 0) {
        var qs2 = url.split('?')[1] || '';
        var params2 = new URLSearchParams(qs2);
        var q2 = params2.get('search') || '';
        var lim2 = parseInt(params2.get('limit') || '25', 10);
        if (isNaN(lim2)) {
            lim2 = 25;
        }
        var et2 = params2.get('employee_type') || '';
        var fteOnlySearch2 = et2 === 'FTE';
        return invokeOrgChartRemote('search', [q2, lim2, fteOnlySearch2]);
    }
    var m2 = url.match(/\/api\/employees\/(.+)/);
    if (m2) {
        var idPart2 = decodeURIComponent(m2[1]);
        return invokeOrgChartRemote('detail', [idPart2]);
    }
    return Promise.reject('Unrecognized org chart request URL');
}

var tree, svg, duration, diagonal;
var root = {};
var fedId_map = {};
var self = {};
var path = [], last = null;
var time_diff, t, to; //Used for timezone
var features =
    window.ORGCHART_FEATURES && window.ORGCHART_FEATURES.length
        ? window.ORGCHART_FEATURES
        : ['faq', 'contact', 'settings'];
var orgchartFeatureJqXhr = null;
var orgchartSuppressHashChange = false;
/* Keep window.settings; never use HTML id="settings" — it replaces window.settings via named window access. */
window.settings = {display: {"name": true, "pronoun": true, "title": false, "reportInfo": false, "fteOnly": false}};
var fedId_to_load = null;
var query_to_search = null;
const FTE = "FTE", ALL_EMPLOYEES = "FTE,CONTRACTOR";
const SALESFORCE_NODE_FEDID = window.ORGCHART_ROOT_FEDERATION_ID || 'organization@internal';

// from https://stackoverflow.com/questions/901115/how-can-i-get-query-string-values-in-javascript
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function resolveOrgChartAssetBase() {
    var b = window.ORGCHART_ASSET_BASE || '';
    if (!b) {
        return '';
    }
    try {
        var u = new URL(b, window.location.href);
        var s = u.href;
        return s.charAt(s.length - 1) === '/' ? s : s + '/';
    } catch (e1) {
        return b.indexOf('/', b.length - 1) >= 0 ? b : b + '/';
    }
}

function installOrgChartFeatureChrome() {
    $(document).on('click', 'a[data-orgchart-feature]', function (e) {
        e.preventDefault();
        var f = this.getAttribute('data-orgchart-feature');
        if (f) {
            loadFeatureModalByName(f);
        }
    });
    $(document).on('click', '[data-orgchart-close]', function (e) {
        e.preventDefault();
        e.stopPropagation();
        try {
            window.location.hash = '';
        } catch (e2) { /* ignore */ }
        $('#modal-wrapper').css('display', 'none');
    });
    $(document).on('click', '#modal-section', function (e) {
        if (e.target.id === 'modal-section') {
            try {
                window.location.hash = '';
            } catch (e3) { /* ignore */ }
            $('#modal-wrapper').css('display', 'none');
        }
    });
}

function syncSettingsModalFromStorage() {
    var boxes = document.querySelectorAll('#overlay input[type="checkbox"][name="display"]');
    for (var i = 0; i < boxes.length; i++) {
        var key = boxes[i].value;
        if (settings.display && Object.prototype.hasOwnProperty.call(settings.display, key)) {
            boxes[i].checked = !!settings.display[key];
        }
    }
}

window.onload = function () {

    var fidRaw = getParameterByName('fid');
    if (fidRaw && fidRaw.length > 0) {
        fedId_to_load = fidRaw;
    }

    //get general search
    var query = getParameterByName('q');
    if (query && query.length > 0) {
        query_to_search = query;
        $('#search').val(query)
    }

    loadSettings();
    installOrgChartFeatureChrome();
    if (navigator.userAgent.indexOf("Version/") !== -1) {
        var settingsLink = document.getElementById("orgchart-settings-link");
        if (settingsLink) {
            settingsLink.style.display = "none";
        }
    }

    var debounce = null;
    $("#search").on('keyup', (function (e) {
        // esc key
        if (e.keyCode === 27) {
            hideSearchResutls();
            $("#search").blur();
            return;
        }

        clearTimeout(debounce);
        debounce = setTimeout(searchEventTriggered, 300);
    }));

    $("#search").focus(searchEventTriggered);

    loadData();

    $("#search").focus();
    $(window).click(function (e) {
        if (!$(e.target).parents('.slds-combobox').length) {
            hideSearchResutls();
        }
    });

    // hashchange does not run for the initial URL fragment on many browsers
    if (window.location.hash) {
        loadFeatureModalForHash();
    }
};

function loadFeatureModalForHash() {
    var feature = window.location.hash.substr(1).split('?')[0];

    if (feature.length === 0) {
        $("#modal-wrapper").css("display", "none");
        return;
    }

    loadFeatureModalByName(feature);
}

window.openOrgChartFeature = function openOrgChartFeature(name) {
    loadFeatureModalByName(name);
};

function loadFeatureModalByName(feature) {
    if (!feature || features.indexOf(feature) === -1) {
        return;
    }
    try {
        if (window.location.hash !== '#' + feature) {
            orgchartSuppressHashChange = true;
            window.location.hash = feature;
        }
    } catch (eHash) {
        orgchartSuppressHashChange = false;
    }

    var base = resolveOrgChartAssetBase();
    var feature_url = base + 'features/' + feature + '.html';
    var bust = '?' + Math.random();

    if (orgchartFeatureJqXhr && orgchartFeatureJqXhr.abort) {
        orgchartFeatureJqXhr.abort();
    }

    function applyHtml(data) {
        $("#overlay").html(data);
        if (feature === 'settings') {
            syncSettingsModalFromStorage();
        }
        showFeatureModal();
    }

    orgchartFeatureJqXhr = $.get(feature_url + bust, applyHtml).fail(function (jqXHR, textStatus, err) {
        orgchartFeatureJqXhr = null;
        if (textStatus === 'abort') {
            return;
        }
        if (typeof fetch === 'function') {
            fetch(feature_url + bust, { credentials: 'same-origin' })
                .then(function (r) {
                    if (!r.ok) {
                        throw new Error('status ' + r.status);
                    }
                    return r.text();
                })
                .then(applyHtml)
                .catch(function (e2) {
                    console.error('Org chart dialog failed to load:', feature_url, textStatus, err, e2);
                });
            return;
        }
        console.error('Org chart dialog failed to load:', feature_url, textStatus, err);
    });
    orgchartFeatureJqXhr.always(function () {
        orgchartFeatureJqXhr = null;
    });
}

window.onhashchange = function () {
    if (orgchartSuppressHashChange) {
        orgchartSuppressHashChange = false;
        return;
    }
    loadFeatureModalForHash();
};

function getData(fteOnly, callback) {
    let type = fteOnly ? FTE : ALL_EMPLOYEES;
    let url = `/api/employees/hierarchy?employee_type=${encodeURIComponent(type)}`;

    callEmployeeEndpoint(url)
        .then(res => callback(res))
        .catch(error => console.log(`Error while fetching hierarchy data: ${error}`));
}

function loadData() {
    var loadNewData = function (data) {
        root = data;
        generateFedIDMap(root);
        generateReportingNumbers(root);
        convertToD3TreeFormat(root);
        generateTree(root, null);
        show(fedId_to_load);
        search(query_to_search);
        loadSelf();
        query_to_search = null; // don't re-trigger search after data is refreshed
    };

    getData(settings.display.fteOnly, function (data) {
        loadNewData(data.hierarchy);
        let dateRefreshed = new Date(data.createdDate);
        $("#dateStringHolder").text((dateRefreshed).toLocaleDateString() + ' ' + (dateRefreshed).toLocaleTimeString());
    });
}

window.showFeatureModal = function showFeatureModal() {
    $("#modal-wrapper").css("display", "block");
};

window.toggleFeatureDisplay = function toggleFeatureDisplay(e) {
    var $wrap = $("#modal-wrapper");
    if (!$wrap.length) {
        return;
    }
    if ($wrap.is(":visible")) {
        var modalSection = document.getElementById("modal-section");
        var modalContainer = document.getElementsByClassName("slds-modal__container")[0];
        var closeButton = document.getElementById("modal-close");
        if (e && (e.target === modalSection || e.target === modalContainer || e.target === closeButton)) {
            window.location.hash = "";
            $wrap.css("display", "none");
        }
    } else {
        $wrap.css("display", "block");
    }
};

window.saveSettings = function saveSettings(e) {
    var display_settings = {};
    var checkboxes = document.querySelectorAll("input[type='checkbox']");

    for (var i = 0; i < checkboxes.length; i++) {
        display_settings[checkboxes[i].value] = checkboxes[i].checked;
    }

    settings.display = display_settings;

    localStorage.setItem("settings", JSON.stringify(settings));

    // get new dataset if fteOnly setting has changed
    if (e.target.name === 'fteOnly') {
        loadData();
    } else {
        generateTree(root, null);
    }
}

function loadSettings() {
    var savedSettings = localStorage.getItem("settings");

    if (savedSettings === null) {
        return;
    }

    savedSettings = JSON.parse(savedSettings);

    //migrate old settings to new settings object
    if (Array.isArray(savedSettings.display)) {
        savedSettings.display.forEach(function (setting) {
            settings.display[setting] = true;
        });
        localStorage.setItem("settings", JSON.stringify(settings));
    } else {
        settings = savedSettings;
    }
}

function generateReportingNumbers(person) {
    var totalReports = 0;

    totalReports += person.directReports.length;
    for (var i = 0; i < person.directReports.length; i++) {
        totalReports += generateReportingNumbers(person.directReports[i]);
    }

    person.totalReports = totalReports;
    person.directReportsCount = person.directReports.length;

    return totalReports;
}

function generateFedIDMap(person, parent_federationId) {

    fedId_map[person.federationId] = {
        name: person.name,
        federationId: person.federationId,
        parent_federationId: parent_federationId,
        title: person.title
    };

    if (person.directReports !== undefined) {
        for (let i = 0; i < person.directReports.length; i++) {
            generateFedIDMap(person.directReports[i], person.federationId);
        }
    } else {
        person.directReports = []
    }
}

function loadSelf() {
    self = callEmployeeEndpoint("/api/employees/me")
        .then(data => self = data)
        .catch(error => console.log(`Error while fetching self data: ${error}`));
}

function convertToD3TreeFormat(person) {
    person.children = person.directReports;
    delete person.directReports;
    person.children.forEach(convertToD3TreeFormat);
}

function buildListItem(item) {
    let photoUrl = item.smallPhotoUrl !== undefined ? item.smallPhotoUrl : "";
    let title = item.title !== undefined ? item.title : "";

    var initial = item.name ? htmlEncode(item.name.charAt(0).toUpperCase()) : '?';
    return '' +
        '<li role="presentation" class="slds-listbox__item">' +
        '<a id="' + federationIdToDomToken(item.federationId) + '_sr" ' + "href='javascript:show(\"" + item.federationId + "\")'" + ' class="slds-media slds-listbox__option slds-listbox__option_entity" role="option">' +
        '<span class="slds-media__figure slds-listbox__option-icon">' +
        '<span class="slds-icon_container slds-m-top_xx-small" style="background-color:#768ea5;border-radius:50%;width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;color:#fff;font-weight:600;font-size:14px;">' +
        (photoUrl
            ? '<img src="' +
              htmlEncode(photoUrl) +
              '" alt="" style="width:32px;height:32px;border-radius:50%;object-fit:cover;" onerror="detailImageFailed(this)"/>'
            : initial) +
        '</span>' +
        '</span>' +
        '<span class="slds-media__body">' +
        '<span class="slds-listbox__option-text slds-listbox__option-text_entity">' + item.name + '</span>' +
        '<span class="slds-listbox__option-meta slds-listbox__option-meta_entity">' + title + '</span>' +
        '</span>' +
        '</a>' +
        '</li>';
}

function getLoader() {
    return '' +
        '<li role="presentation" class="slds-listbox__item">' +
        '<div class="slds-align_absolute-center slds-p-top_medium">' +
        '<div role="status" class="slds-spinner slds-spinner_x-small slds-spinner_inline">' +
        '<span class="slds-assistive-text">Loading</span>' +
        '<div class="slds-spinner__dot-a"></div>' +
        '<div class="slds-spinner__dot-b"></div>' +
        '</div>' +
        '</div>' +
        '</li>';
}

function showSearchResutls() {
    $(".slds-combobox").addClass("slds-is-open");
}

function hideSearchResutls() {
    $(".slds-combobox").removeClass("slds-is-open");
}

function searchEventTriggered() {
    var query = $("#search").val();
    search(query);
}

function search(query) {

    if (!query) {
        return;
    }

    var searchResutlsElem = $("#searchResults");

    query = query.toLowerCase();
    if (query.length < 2) {
        hideSearchResutls();
        searchResutlsElem.html("");
        return;
    }

    searchResutlsElem.html(getLoader());

    showSearchResutls();

    let type = settings.display.fteOnly ? FTE : ALL_EMPLOYEES;

    let url = `/api/employees?search=${encodeURIComponent(query)}&employee_type=${encodeURIComponent(type)}&limit=25`;

    callEmployeeEndpoint(url)
        .then(searchResponse => {
            logNumResults(query, searchResponse.length);
            let html = "";
            for (let i = 0; i < searchResponse.length; i++) {
                html += buildListItem(searchResponse[i]);
            }
            $("#searchResults").html(html);
        }).catch(error => console.log("We ran into issues while returning the search results: " + error));
}

window.show = function show(federationId) {

    if (!federationId || federationId.length <= 1) {
        return;
    }

    hideSearchResutls();

    var target = fedId_map[federationId];
    path = [];

    do {
        path.push(target.federationId);
        target = fedId_map[target.parent_federationId];
    } while (target);

    displayPath();

    if (window.gtag) {
        gtag('event', 'Search', { Show_User: federationId });
    }
}

function displayPath() {
    if (!last) {
        last = root;
        var root_id = path.pop();
        var highlightString = "highlightPath('" + root_id + "','" + path[path.length - 1] + "')";
        setTimeout(highlightString, 20);
    }

    if (last._children) {
        last.children = last._children ? last._children : [];
        last._children = null;
        update(last);
    }


    var next, next_id = path.pop();

    if (last.children) {
        for (var i = 0; i < last.children.length; i++) {
            if (next_id === last.children[i].federationId) {
                next = last.children[i];
                break;
            }
        }
    }

    if (next) {
        var highlightString = "highlightPath('" + last.federationId + "','" + next.federationId + "')";
        setTimeout(highlightString, 20);
        last = next;
        setTimeout(displayPath, 10);
    } else {
        getDetails(last);
        setFedIdQueryParam(last.federationId);
        last = null;
    }
}

window.highlightPath = function highlightPath(source_federationId, target_federationId) {
    $("#" + linkPathElementId(source_federationId, target_federationId)).attr("class", "link highlight");
}

/**
 * Stable HTML/SVG id token for a federation id (email, username, or 15/18-char User Id).
 * Raw emails/ids are not valid/safe as CSS/jQuery # selectors; User Ids have no "@"
 * and the old truncateFedId logic produced "" for all of them (broken links).
 */
function federationIdToDomToken(federationId) {
    if (federationId == null || federationId === '') {
        return 'oc_empty';
    }
    var s = String(federationId);
    var at = s.lastIndexOf('@');
    if (at <= 0) {
        return 'oc_' + s.replace(/[^a-zA-Z0-9]/g, '_');
    }
    var local = s.substring(0, at);
    var domain = s.substring(at + 1);
    return 'oc_m_' + local.replace(/[^a-zA-Z0-9]/g, '_') + '_at_' + domain.replace(/[^a-zA-Z0-9.]/g, '_');
}

function linkPathElementId(sourceFed, targetFed) {
    return federationIdToDomToken(sourceFed) + '--' + federationIdToDomToken(targetFed);
}

function generateTree(root) {
    var headerHeight = 50, footerHeight = 35;
    var margin = {top: 20, right: 120, bottom: 25, left: 120},
        width = 2100 + margin.right,
        height = window.innerHeight - headerHeight - footerHeight - margin.top - margin.bottom - 19;

    duration = 750;

    tree = d3.layout.tree()
        .size([height, width]);

    diagonal = d3.svg.diagonal()
        .projection(function (d) {
            return [d.y, d.x];
        });

    d3.selectAll("#org-tree svg").remove();
    d3.selectAll("#org-tree .slds-spinner").remove();

    svg = d3.select("#org-tree").append("svg")
        .attr("width", width)
        .attr("height", height + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + (margin.left - 100) + "," + margin.top + ")");

    root.x0 = height / 2;
    root.y0 = 0;

    var rootChildren = root.children;
    for (let i = 0; rootChildren != null && i < rootChildren.length; i++) {
        if (rootChildren[i].children != null) {
            rootChildren[i].children.forEach(collapse);
        }
    }

    update(root);
}

function collapse(d) {
    if (d.children) {
        d._children = d.children;
        d._children.forEach(collapse);
        d.children = null;
    }
}


function update(source) {

    // Compute the new tree layout.
    var nodes = tree.nodes(root).reverse(),
        links = tree.links(nodes);

    // Normalize for fixed-depth.
    nodes.forEach(function (d) {
        d.y = d.depth * 180;
    });

    let i = 0;

    // Update the nodes…
    var node = svg.selectAll("g.node")
        .data(nodes, function (d) {
            return d.federationId || (d.federationId = ++i);
        });

    // Enter any new nodes at the parent's previous position.
    var nodeEnter = node.enter().append("g")
        .attr("class", "node")
        .attr("id", function (d) {
            return federationIdToDomToken(d.federationId);
        })
        .attr("transform", function (d) {
            return "translate(" + source.y0 + "," + source.x0 + ")";
        }).attr("style", function (d) {
            if (d.federationId === SALESFORCE_NODE_FEDID) {
                return "visibility: hidden;"
            }
        })
        .on("click", click);

    nodeEnter.append("circle")
        .attr("r", 1e-6)
        .style("fill", function (d) {
            return d._children ? "lightsteelblue" : "#fff";
        });

    if (navigator.userAgent.indexOf("Version/") == -1) {
        nodeEnter.append("foreignObject")
            .html(getNodeHTML)
            .attr("width", "150")
            .attr("height", function (d) {
                var elemHeight = this.children[0].children[0].children[0].clientHeight + 6;
                this.children[0].style.height = elemHeight + "px";
                return elemHeight;
            })
            .attr("x", function (d) {
                return "-160px"
            })
            .attr("y", function () {
                return -1 * this.height.baseVal.value / 2;
            });

    } else {
        nodeEnter.append("text")
            .attr("x", function (d) {
                return d.children || d._children ? -10 : 10;
            })
            .attr("dy", "0.35em")
            .attr("text-anchor", function (d) {
                return d.children || d._children ? "end" : "start";
            })
            .text(function (d) {
                return d.name;
            })
            .style("fill-opacity", 1e-6);
    }

    nodeEnter.append("svg:title")
        .text(function (d) {
            return d.title
        });

    // Transition nodes to their new position.
    var nodeUpdate = node.transition()
        .duration(duration)
        .attr("transform", function (d) {
            return "translate(" + d.y + "," + d.x + ")";
        });

    nodeUpdate.select("circle")
        .attr("r", 4.5)
        .style("fill", function (d) {
            if (d._children && d._children.length == 0)
                return "#fff";
            return d._children ? "lightsteelblue" : "#fff";
        });

    nodeUpdate.select("text")
        .style("fill-opacity", 1);

    // Transition exiting nodes to the parent's new position.
    var nodeExit = node.exit().transition()
        .duration(duration)
        .attr("transform", function (d) {
            return "translate(" + source.y + "," + source.x + ")";
        })
        .remove();

    nodeExit.select("circle")
        .attr("r", 1e-6);

    nodeExit.select("text")
        .style("fill-opacity", 1e-6);

    // Update the links…
    var link = svg.selectAll("path.link")
        .data(links, function (d) {
            return d.target.federationId;
        });

    // Enter any new links at the parent's previous position.
    link.enter().insert("path", "g")
        .attr("id", function (d) {
            return linkPathElementId(d.source.federationId, d.target.federationId);
        })
        .attr("class", function (d) {
            return "link";
        })
        .attr("d", function (d) {
            var o = {x: source.x0, y: source.y0};
            return diagonal({source: o, target: o});
        })
        .attr("style", function (d) {
            if (d.source.federationId === SALESFORCE_NODE_FEDID) {
                return "visibility: hidden;"
            }
        });

    // Transition links to their new position.
    link.transition()
        .duration(duration)
        .attr("d", diagonal);

    // Transition exiting nodes to the parent's new position.
    link.exit().transition()
        .duration(duration)
        .attr("d", function (d) {
            var o = {x: source.x, y: source.y};
            return diagonal({source: o, target: o});
        })
        .remove();

    // Stash the old positions for transition.
    nodes.forEach(function (d) {
        d.x0 = d.x;
        d.y0 = d.y;
    });
}


window.detailImageFailed = function detailImageFailed(img) {
    img.remove();
}

window.logNumResults = function logNumResults(q, n) {}

window.logProfileClick = function logProfileClick(id) {
    if (window.gtag) {
        gtag('event', 'User_Details', { User_Record: id });
    }
}

window.logSlackDMClick = function logSlackDMClick(id) {
    if (window.gtag) {
        gtag('event', 'User_Details', { Slack_DM: id });
    }
}

window.logEmailClick = function logEmailClick(id) {
    if (window.gtag) {
        gtag('event', 'User_Details', { Email: id });
    }
}

window.logDeskClick = function logDeskClick(id) {
    if (window.gtag) {
        gtag('event', 'User_Details', { Desk: id });
    }
}

function getDetails(d) {
    let url = `/api/employees/${d.federationId}`;

    callEmployeeEndpoint(url)
        .then(data => {
            var mediaBody = "<div class='slds-media__body'>";
            var profileHref = data.userRecordUrl
                ? htmlEncode(data.userRecordUrl)
                : htmlEncode('/lightning/r/User/' + data.orgUserId + '/view');
            mediaBody +=
                "<a aria-label='Open user record' target='_blank' class='slds-text-heading_small' href='" +
                profileHref +
                "' onclick='logProfileClick(\"" +
                data.orgUserId +
                "\")'>" +
                htmlEncode(data.name) +
                '</a>';
            mediaBody += "<div class='slds-text-title font-style_italic'>" + htmlEncode(data.title) + "</div>";

            if (data.pronoun && settings.display.pronoun) {
                mediaBody += "<div class='slds-text-body_small font-style_italic'>" + "<a id='pronounLabel' target='_blank' href=''>Pronoun: </a>" + htmlEncode(data.pronoun) + "</div>";
            }

            if (self.slackEnterpriseId && data.slackUserId) {
                mediaBody += "<a class='display_block' target='_blank' title='Message in Slack' href='slack://user?team=" + htmlEncode(self.slackEnterpriseId) + "&id=" + htmlEncode(data.slackUserId) + "' onclick='logSlackDMClick(\"" + data.email + "\")'>Message in Slack</a>";
            }

            if (data.mobilePhone && data.mobilePhone !== 'TBD') {
                mediaBody += "<a target='_blank' title='Mobile' href='tel:" + htmlEncode(data.mobilePhone) + "'>" + htmlEncode(data.mobilePhone) + '</a>';
            }

            mediaBody += "<a class='display_block' target='_blank' href='mailto:" + htmlEncode(data.email) + "' onclick='logEmailClick(\"" + data.email + "\")'>" + htmlEncode(data.email) + "</a>";

            if (data.location) {
                mediaBody += "<div class='slds-text-title font-style_italic'>" + data.location + "</div>";
            }

            mediaBody += "</div>";
            var mediaFigure = "<div>";
            if (data.mediumPhotoUrl || data.largePhotoUrl) {
                mediaFigure += "<img src='" + htmlEncode(data.mediumPhotoUrl || data.largePhotoUrl) + "' alt='' class='userPhoto' onerror='detailImageFailed(this)'/>";
            } else {
                // Default profile image pattern: /img/userprofile/default_profile_200_v2.png
                mediaFigure += "<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAADZtJREFUeAHtnflvFdcVx4/3HQy2AWMWx+whcdiaECAkaROpNItSqf0latX2T8mfkd8qtVIr9QektkkUoTZqAq2VBRIgOOwYsA1ewMRsNrbpnEFICJvDuzPz5s1cf470hHnn3jvnfu75vpm5c2em7IMP998XDAIQmJNA+Zzf8iUEIBASQCAkAgQMAgjEgIMLAgiEHICAQQCBGHBwQQCBkAMQMAggEAMOLgggEHIAAgYBBGLAwQUBBEIOQMAggEAMOLgggEDIAQgYBBCIAQcXBBAIOQABgwACMeDgggACIQcgYBBAIAYcXBBAIOQABAwCCMSAgwsCCIQcgIBBAIEYcHBBAIGQAxAwCCAQAw4uCCAQcgACBgEEYsDBBQEEQg5AwCCAQAw4uCCAQMgBCBgEEIgBBxcEEAg5AAGDAAIx4OCCAAIhByBgEEAgBhxcEEAg5AAEDAIIxICDCwIIhByAgEEAgRhwcEEAgZADEDAIIBADDi4IIBByAAIGAQRiwMEFAQRCDkDAIIBADDi4IIBAyAEIGAQQiAEHFwQQCDkAAYMAAjHg4IIAAiEHIGAQQCAGHFwQqARB+gSqKiukc3mrrFzaIm2LmqS1uUlqa6qkpvrBcExMTsndiXsyMjYuw9fH5dLVUbkwMCL3pqbTD3aebxGBpJQAZWUi61ctk22bOuWZjjaprKh44pYr6yqkoa5GWpobZUNne1huanpazvcPy+HeC3Lq4hW5f/+J1XEkSACBJAjzSU0927Vc3tz5nCxsrH9Skad+r4JaFwhMPzdu3pYDPcflxLmBp9ajQDwCCCQeP7O27gH27e6Wro4lZjlXpwrtV2+8KOf6h+STQ0dldOymaxOUL5BA2Qcf7mdnXSCsQouVl5fJ6zs2yc7utVJRXtx5kOmZGek5ekY++7pXZmYYykLHqNBy7EEKJVVgOT0B//WbL8ralUsLrBGvmApw95b1srRlofztwJecyMfDOat2cX/eZm3O7y/qgpmo3769OzVxPEpTBanb1hiw5AggkIRYLmiok9+/u1dWLFmcUIvuzei2NQaNBUuGAAJJgKMeVv3mrV3hNY0EmovVhF5X0Vg0Jiw+AQQSn6G89cqW8GJfAk0l0oReeNSYsPgEEEhMhi+sXyXd61bGbCX56hqTxobFI4BAYvDTX+pf7OmO0UJxq2psGiMWnQACic5O3nl1a3Csn92Zco1NY8SiE0AgEdnpeqqVS0s3Y1Vo2BqjxopFI4BAonGTvds2RKyZfrU8xZo+HXuLCMTmM6d3dXuLrG5vndOXxS81Vo0ZcyeAQNyZyStb87P3eNi9PMb8MPZS/otAHOnX11bn8phez0M0dsyNAAJx4yVrViyRMr37KWemMWvsmBsBBOLGS9aktErXMayCiuc59oI6WIRCCMQRap5/hfMcu+MwJVYcgTigbG9tDu8Vd6iSqaJ6n7v2ASucAAIpnJW0t+U/uXzog8OQxS6KQBwQLl7Q4FA6m0V96EOaZBGIA+3mpuhPJXHYTFGL+tCHogJ6rHEE8hgQ6791HlxH8KEP1hgl7UMgDkSrM7xyt9Bu+NCHQvuaRDkE4kCxsjL/uHzog8OQxS6a/xGPjaDwBqamZgovnNGSPvQhTbQIxIH25L0ph9LZLOpDH9Iki0AcaN+ZmHQonc2iPvQhTbIIxIH22Phth9LZLOpDH9Iki0AcaF/78ZZD6WwW9aEPaZJFIA60B4fHHEpns6gPfUiTLAJxoD04Mia37kw41MhWUY1d+4AVTgCBFM4qLHn28pBjjewUz3PspaKIQBzJn7101bFGdornOfZSUUQgjuT1V/h+Dl8QqDGzB3Ec7KA4AnFkdvvuZPgyTcdqJS+uLwDV2DE3AgjEjVdY+osjJyPUKm2VPMZcWmIPto5AIoxC3+Co9A2ORKhZmioaq8aMuRNAIO7MwhqfH87PXiRPsUYcjqJVQyAR0eox/aWr1yLWTq+axqixYtEIIJBo3MJa//jPkeCtstld4auxaYxYdAIIJDo7GRkbl48PHo3RQnGramwaIxadAAKJzi6s+d2pi3L09KWYrSRfXWPS2LB4BBBIPH5h7Y+++DZTv9S619CYsPgEEEh8hsF5yLT8+aP/yvD10h/OaAwai8aExSeAQOIzDFv48dYd+ePfP5fLQ6Wb2dJtawwaC5YMAQSSDMewlTsT9+RP/zwkZ0qwoFG3qdvWGLDkCCCQ5FiGLemhzV8/7ZFD356S6ZniPwVFt6Hb0m1yWJXwYAbNZfcdxsn3NbUWZ2buy7++PCHfBrNI+3Z3S1dHcV5cc65/SD45dFRGx26m1rf5tiEEUsQR18TVE+Znu5bLmzufk4WNyTzb98bN23Kg57icODdQxOhpWgkgkBTyQBO59/yArF+1TLZt6gzfcVhZUeG05anp6XDJyOHeC3Lq4pXgnhSn6hSOSACBRATnWk0T+mTflfBTVVkhnctbZeXSFmlb3CStC5uktqZKaqofDMfE5JTcDU62R26My/C18WDN16hcGBjhHMMVegLlEUgCEF2b0JPp0xevhh/XupRPlwCzWOnyZms5I4BAcjZghJsuAQSSLm+2ljMCnINEGDA9yf7J5i55bu0KaW1ulItXRuWzr3qlf+h6hNaSr9JYXyu7t6yTVctawmskp4NZr+NnLzPzFQF12Qcf7mfCsEBwCxrq5KXnu2Tbxs5gxqlqVq3jZy4HFwi/lxs3S7MWSmfBdr2wTnY+v0aqHnsbli5i7Dl2JlyaPz1d/Cv8s+Dk9AsEUsDALWtZKC93r5XNazqkvNw+Kp0KZqh6jp8Nln+clonJdNZFVVSUy45nn5FXtm6Q+qe8R1EfP/pN73n56vvzuX6MagHDlkgRBGJg1EOUvds3RFoqolO5vef65fAPfeEhmLGZyK721mbZsmFVeKhXV1Pt1I7uRY6duSQHg3Vc127k/6n1Tp13KIxA5oC1ul2FsVGeWd42h9f9K11yonf3nR8YDh8erWu1olhZWZno3kwvMnavWylLg7/jmj5x8fuz/aLPzcrC/Sxx+5N0fQTyCFHdY7y2Y1OYgI98neifegjWP3w9fCLK1dEb4dMO9YmHd4LP7bsPnhxfX1sj+rrm+mCvUF9XLUsWLwiuui+WjiWLZp1bJBWcCkWXw+gjgoau/ZhUs7lvB4EEQ9jcVC9vvLQ5WFTYkfsBjdsBFcqRk33hrFyeX/UQl8PD+vN6mlena/XEdmf3GnFdPPgQoG//6mGcztJtDn4s9Pyk59hZmc+zXvNWIBs722XfnhekKbhmgM0moNPYP3txs2wPVh9/fPC74C7J/L4XZXbvCv9m3gmkuqpSfr7r+WD2Z3XhlOZxyeamBnl/3y75+sT58B6U+XbX4rwSiJ6Ev/f6tuCco2Eep3y0rut1lq6ONtn/2TeZWTEQrSduteyrXm5tZbr0ni3r5Xfv7EEcMUZp8cJG+cO7e8OLpjGayVXVebEH0fvCde0UFp9AeXlZePuwLrv59H/H4jeY8Ra8FkhFsCzklz/dzvRtEZLwpWC9V2N9TXjIFfXCZxHCSrxJbwWi65Pe3/dyYlfDEyfvQYOb16wIL2j+5ZOeVB5xVApk3p6DvPfadsSRQkbpI4104sNX81Ige7auD1fe+jpoWeuX7kl0EsRH804gusL1tWChIZYugVd3bBRl75t5J5C392556j0bvg1iFvqjEyLK3jfzSiB6Q5OPv2J5STplr2Pgk3klEL3dFCstAd/GwBuB6D0T7D1KKw7duo6BjoUv5o1A9Lm3WDYI+DQW3ghkRXDHHZYNAj6NhTcCaVvUlI3sIArxaSy8EYjew41lg4BPY+GNQGrneJBbNtJl/kVRE9yU5ot5IxBfBsSHfuh97b4YAvFlJOlHUQggkKJgpVFfCCAQX0aSfhSFgDcCmbw3VRRANOpOIK2HdrtH5l7DG4GM37rr3ntqFIXA+G1/xsIbgQwEz7vFskFgcHgsG4EkEIU3AvnhwmACOGgiCQI+jYU3AjnZNyijN24mMb60EYOAjoGOhS/mjUD00TMHeo77Mi657YeOgU+PAfJGIJpRp/quyMEjp3KbXHkPXNnrGPhkXglEB+bfX51AJCXIUBWHsvfN/FlV9sjI6EBdHroWPiKzJXieLFY8AnrOoYdVvu05HhLzUiDaOR2wM5euyobV7aLvAlnetkiaGmpFX3+ARSegF2T1mpNOq+tslZ6Q+3TO8TgZr7NFB07fu6cfDAJRCHh3DhIFAnUg8CQCCORJZPgeAgEBBEIaQMAggEAMOLgggEDIAQgYBBCIAQcXBBAIOQABgwACMeDgggACIQcgYBBAIAYcXBBAIOQABAwCCMSAgwsCCIQcgIBBAIEYcHBBAIGQAxAwCCAQAw4uCCAQcgACBgEEYsDBBQEEQg5AwCCAQAw4uCCAQMgBCBgEEIgBBxcEEAg5AAGDAAIx4OCCAAIhByBgEEAgBhxcEEAg5AAEDAIIxICDCwIIhByAgEEAgRhwcEEAgZADEDAIIBADDi4IIBByAAIGAQRiwMEFAQRCDkDAIIBADDi4IIBAyAEIGAQQiAEHFwQQCDkAAYMAAjHg4IIAAiEHIGAQQCAGHFwQQCDkAAQMAgjEgIMLAgiEHICAQQCBGHBwQQCBkAMQMAggEAMOLgggEHIAAgaB/wOXQAFktG7WMQAAAABJRU5ErkJggg==' alt='' class='userPhoto' onerror='detailImageFailed(this)'/>";
            }
            mediaFigure += "</div>";

            if (!to) {
                to = setTimeout(updateTime, 250);
            }

            var mediaObject = "<div class='detailContainer'>" + mediaBody + mediaFigure + "</div>";
            $("#toggle-title").html("");
            $("#aria-expanded").html("true");
            $("#collapse").addClass("slds-is-open");
            $("#details").html(mediaObject);
            $("#pronounLabel").attr('href', $("#details").attr("pronounArticleUrl"));
        })
        .catch(error => console.log(`Error while fetching employee detail data: ${error}`));

    if (window.gtag) {
        gtag('event', 'User_Details', { Load: d.federationId });
    }
}

function getNodeHTML(d) {
    var s = "";

    if (settings.display.name) {
        s += htmlEncode(d.name) + '<br />';
    }
    if (settings.display.title) {
        if (d.title) {
            s += '<i>' + htmlEncode(d.title) + '</i><br />';
        }
    }
    if (settings.display.reportInfo) {
        if (d.totalReports !== 0) {
            s += htmlEncode(d.directReportsCount) + " | " + htmlEncode(d.totalReports);
        }
    }

    return '<body xmlns="http://www.w3.org/1999/xhtml"> \
                <div class="tableWrap"> \
                    <div class="tableCell"> \
                        <p>' + s + '</p> \
                    </div> \
                </div> \
            <body>';
}

window.htmlEncode = function htmlEncode(value) {
    return $("<div/>").text(value).html();
}

function updateTime() {
    t = new Date(new Date().getTime() + time_diff * 60 * 60 * 1000);
    $("#date").html(t.toLocaleTimeString());
    to = setTimeout(updateTime, 400);
}

// Toggle children on click.
window.click = function click(d) {
    //window.location.hash = d.id;
    getDetails(d);

    if (d.children) {
        d._children = d.children;
        d.children = null;
    } else {
        d.children = d._children;
        d._children = null;
    }

    setFedIdQueryParam(d.federationId);
    update(d);
}

function setFedIdQueryParam(fedId) {
    if (history.pushState) {
        var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?fid=' + fedId;
        window.history.pushState({path: newurl}, '', newurl);
    }
}

//ORG IS GETTING TOO BIG!!! RESET ME PLEASE!!! :-O
window.reset = function reset() {
    if (!root.children) {
        root.children = root._children;
        root._children = null;
    }

    hideSearchResutls();

    root.children.forEach(function (d) {
        collapse(d);
    });

    update(root);

    d3.selectAll('.highlight')
        .classed('highlight', false);

    if (window.gtag) {
        gtag('event', 'Chart_Controls', { Reset: 'Button Clicked' });
    }
}

window.cardCollapse = function cardCollapse() {
    var element = document.getElementById("collapse");
    element.classList.toggle("slds-is-open");
    var a = document.getElementById("toggle-title");
    if (a.innerText === "") {
        a.innerText = "More Details";
    } else if (a.innerText === "More Details") {
        a.innerText = "";
    }
}
